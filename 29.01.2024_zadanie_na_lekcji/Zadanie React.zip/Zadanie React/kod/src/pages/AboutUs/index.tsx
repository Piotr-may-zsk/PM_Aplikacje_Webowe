export default function AboutUs() {
  return <>About Us</>;
}