export default function Clicker() {
  return <>Clicker</>;
}