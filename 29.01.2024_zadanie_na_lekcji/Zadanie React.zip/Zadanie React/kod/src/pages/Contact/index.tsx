export default function Contact() {
  return <>Contact</>;
}