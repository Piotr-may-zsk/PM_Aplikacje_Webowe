import './container.scss'

export default function Container() {
  return (
    <div className='container'>
    </div>
  )
}