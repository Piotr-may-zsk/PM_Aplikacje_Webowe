import './footer.scss'

export default function Footer() {
  return <footer id="app-footer">Footer</footer>
}