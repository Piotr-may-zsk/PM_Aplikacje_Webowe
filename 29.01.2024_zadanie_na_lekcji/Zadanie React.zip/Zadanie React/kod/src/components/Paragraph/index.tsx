import './paragraph.scss'

export default function Paragraph() {
  return <p>Paragraph</p>
}