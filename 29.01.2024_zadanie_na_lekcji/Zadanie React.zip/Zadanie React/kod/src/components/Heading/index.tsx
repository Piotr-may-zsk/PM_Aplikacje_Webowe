export default function Heading() {
  return (
    <>
      Heading
    </>
  )
}